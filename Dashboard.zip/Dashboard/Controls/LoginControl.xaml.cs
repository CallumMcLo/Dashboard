﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Dashboard
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class LoginControl : UserControl
    {
        public LoginControl()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e) //Event fires when this control is loaded
        {
            UserIDEntry.Focus(); //Make it so user can type into user ID box immediately and not have to click on it.
        }

        private void SignIn_Click(object sender, RoutedEventArgs e) //Do login validation here
        {
#if !DEBUG //Allows skipping logging in if in DEBUG mode.
            if (!IsValid(UserIDEntry.Text, PasswordEntry.Password)) //Check if username/password passes requirements
            {
                MessageBox.Show("Invalid Username or Password");
                ClearPassword();
                return;
            }

            if (!(int.TryParse(UserIDEntry.Text, out int userID)))
                return;

            User user = new User(userID, PasswordEntry.Password);
            Main.ShowLoggedInWindows(user);
#else
            Main.ShowLoggedInWindows(null);
#endif
            ClearInput(); //Clear entered username/password from window

#if !DEBUG
            user = null;  //Clear User class from memory
#endif

            Main.SetControlVisibility(this, false);
        }

        private bool IsValid(string username, string password) 
        {
            if (!int.TryParse(UserIDEntry.Text, out int userID) || UserIDEntry.Text.Length != 5) //UserID cannot be less than or greater than 5 chars
                return false;

            if (PasswordEntry.Password.Length != 8)     //User passwords can only be 8 chars
                return false;

            return true;
        }

        public void ClearInput()
        {
            UserIDEntry.Text = "";
            ClearPassword();
        }

        private void ClearPassword()
        {
            PasswordEntry.Password = "";
        }

        private void Grid_KeyDown(object sender, KeyEventArgs e) //Keydown event fires whenever a key is pushed.
        {
            if (e.Key == Key.Enter)         //Allow user to hit enter to login
            {
                SignIn_Click(this, null);
            }
        }
    }
}
